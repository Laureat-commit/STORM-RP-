const { cmd } = require('../command');
const config = require('../config'); // Si tu utilises un fichier de configuration pour l'image

cmd({
    pattern: "regle3",
    desc: "Affiche les informations REGLE3 avec une image",
    category: "basics",
    filename: __filename,
},
async (conn, mek, m, { from, reply, isOwner }) => {
    const maText = `
*🎮
`;

    // URL de l'image à afficher
    const imageUrl = 'https://files.catbox.moe/xhza25.png'; // Remplace par ton image ou config.ALIVE_IMG

    try {
        // Envoi de l'image avec la légende
        return await conn.sendMessage(from, {
            image: { url: imageUrl },  // Utilisation de l'URL de l'image
            caption: maText,           // Texte à afficher en légende
        }, { quoted: mek });

    } catch (err) {
        console.error("Erreur lors de l'envoi de l'image:", err);
        reply("🙇‍♂️ Erreur lors de l'envoi de l'image. Réessaie plus tard.");
    }
});
